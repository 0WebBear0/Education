package education.java.Univursity.laba6;

import java.util.ArrayList;
import java.util.Scanner;

public class part1 {
    public static void main(String[] args) {

        ArrayList <Integer> inputArray = new ArrayList<Integer>();

        Scanner sc = new Scanner(System.in);

        while (true){
            System.out.println("Input integer. If you want leave input '0' ");
            int addedInt = sc.nextInt();
            if (addedInt != 0){
                inputArray.add(addedInt);
            }
            else break;
        }

        //worker code

        int middleData = 0;
        int sumDataLeft = 0;
        int sumDataRight = 0;

        for (Integer i : inputArray) {
            middleData += i;
        }
        middleData = (int) Math.ceil(middleData / inputArray.size());

        System.out.println(middleData);
        for (Integer i : inputArray) {
            if (middleData >= i){
                sumDataLeft += i;
            }
            else sumDataRight += i;
        }

        System.out.println(sumDataLeft);
        System.out.println(sumDataRight);
    }
}
