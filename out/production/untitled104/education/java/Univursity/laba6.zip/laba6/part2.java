package education.java.Univursity.laba6;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class part2 {
    public static void main(String[] args) {

        ArrayList<Integer> inputArray = new ArrayList<>();

        Scanner sc = new Scanner(System.in);

        while (true){
            System.out.println("Input integer. If you want leave input '0' ");
            int addedInt = sc.nextInt();
            if (addedInt != 0){
                inputArray.add(addedInt);
            }
            else break;
        }

        inputArray.sort(Comparator.naturalOrder());

        int inputArrayLength = inputArray.size();
        int inputArrayNegative = inputArray.get(0) * inputArray.get(1);
        int inputArrayPositive = inputArray.get(inputArrayLength - 1) * inputArray.get(inputArrayLength - 2);

        System.out.println("Negative * "+inputArrayNegative);
        System.out.println("Positive * "+inputArrayPositive);
        if (inputArrayNegative > inputArrayPositive){
            System.out.println("Max from 3: "+inputArrayNegative * inputArray.get(inputArrayLength - 1));
        }
        else System.out.println("Max from 3: "+inputArrayPositive * inputArray.get(inputArrayLength - 3));
    }
}
