package education.java.Univursity.Vigenere;

public class Output {

    public static void main(String[] args) {

        Algorithm algorithm = new Algorithm("asdsad", "lqpo", 1);

        System.out.println(algorithm.getVigenere());
    }
}
