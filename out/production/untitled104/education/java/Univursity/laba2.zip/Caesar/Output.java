package education.java.Univursity.Caesar;

public class Output {

    public static void main(String[] args) {

        Algorithm algorithm = new Algorithm("ZY",1);

        System.out.println(algorithm.getCaesar());
    }
}
